Page({
  data: {
    records: [
      {
        time: '2025-04-10 10:15',
        clothing: '白色T恤',
        model: '女模特 A'
      },
      {
        time: '2025-04-11 14:30',
        clothing: '红色连衣裙',
        model: '女模特 A'
      },
      
      {
        time: '2025-04-12 10:15',
        clothing: '羽绒服',
        model: '女模特 A'
      }
    ]
  }
})
